/*
 * Copyright (c) 2012, 2014, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package sun.util.locale.provider;

/**
 * LocaleProviderAdapter implementation for the Unix locale data
 *
 * @author Naoto Sato
 */
public class HostLocaleProviderAdapterImpl {
}
